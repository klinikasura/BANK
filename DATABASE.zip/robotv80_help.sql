-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 26 Bulan Mei 2026 pada 07.07
-- Versi server: 10.4.16-MariaDB
-- Versi PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikdraisyah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `robotv80_help`
--

CREATE TABLE `robotv80_help` (
  `id_help` int(11) NOT NULL,
  `id_karyawan` int(100) NOT NULL,
  `no_tlp` varchar(100) NOT NULL,
  `pesan` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `robotv80_help`
--

INSERT INTO `robotv80_help` (`id_help`, `id_karyawan`, `no_tlp`, `pesan`) VALUES
(1, 2, '1234567890', '1'),
(2, 1, '085369347778', 'Tes'),
(3, 2, '1234567890', '1'),
(4, 1, '085369347778', 'Tes'),
(5, 1, '085369347778', 'Tes'),
(6, 2, '1234567890', '1');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `robotv80_help`
--
ALTER TABLE `robotv80_help`
  ADD PRIMARY KEY (`id_help`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `robotv80_help`
--
ALTER TABLE `robotv80_help`
  MODIFY `id_help` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
