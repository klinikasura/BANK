-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 26 Bulan Mei 2026 pada 07.08
-- Versi server: 10.4.16-MariaDB
-- Versi PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikdraisyah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `robot80_mou`
--

CREATE TABLE `robot80_mou` (
  `id` int(200) NOT NULL,
  `nama_pt` varchar(1000) NOT NULL,
  `alamat_pt` varchar(1000) NOT NULL,
  `mulai_mou` date NOT NULL,
  `habis_mou` date NOT NULL,
  `no_mou` varchar(1000) NOT NULL,
  `pj_klinik` varchar(1000) NOT NULL,
  `pj_pt` varchar(1000) NOT NULL,
  `nama_klinik` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `robot80_mou`
--

INSERT INTO `robot80_mou` (`id`, `nama_pt`, `alamat_pt`, `mulai_mou`, `habis_mou`, `no_mou`, `pj_klinik`, `pj_pt`, `nama_klinik`) VALUES
(1, 'PT. ADMINISTRASI MEDIKA (ADMEDIKA)', 'JAKARTA PUSAT', '2022-09-01', '2024-08-31', '298/PKS/ADMEDIKA/IX/2022', 'dr. AYU ANGGIA TRIDA', 'dr. M. RIZAI A. HAKIM', 'PT. ASURA MEDIKALOKA BERJAYA'),
(2, 'PT. ASURANSI JIWA INHEALTH INDONESIA (MANDIRI INHEALTH)', 'PALEMBANG', '2024-09-09', '2026-09-09', '106/AJII/KOP-PLB/KTR/0824', 'dr. H. TOMAS EDIBA, SpOG', 'Msy. Fadilla Febriyanti', 'KLINIK ASURA'),
(3, 'PT. BANK RAKYAT INDONESIA (BRI)', 'KCP TUGUMULYO', '2023-01-02', '2024-01-02', 'B.KCP-IV/OPS/01/2023', 'dr. M. RICKY MEIRIZKIAN', 'HELMI WIJAYADI', 'KLINIK ASURA'),
(4, 'PT. JAT TEKNIK MEDIKA GROUP DAN PT. TENANG JAYA SEJAHTERA (LIMBAH B3)', 'LAMPUNG', '2026-06-27', '2027-06-27', '1257/PP.LB3/KA/JATTMG-TJS/IV/2025', 'dr. H. TOMAS EDIBA, SpOG', 'JONI AMBAR TRISNO & BAMBANG GURITNO', 'KLINIK ASURA'),
(5, 'PT. YAYASAN SIMRS KHANZA INDONESIA (YASKI)', 'JAWA BARAT', '2024-02-08', '2029-02-08', '128/MOU/YASKI/II/2024', 'dr. H. TOMAS EDIBA, SpOG', 'KUSMANTO LESMANA, SE, MARS', 'KLINIK ASURA');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `robot80_mou`
--
ALTER TABLE `robot80_mou`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
