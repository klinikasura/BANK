-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 26 Bulan Mei 2026 pada 07.08
-- Versi server: 10.4.16-MariaDB
-- Versi PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikdraisyah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `robot80_tb_kelas`
--

CREATE TABLE `robot80_tb_kelas` (
  `id` int(100) NOT NULL,
  `nama_kelas` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `robot80_tb_kelas`
--

INSERT INTO `robot80_tb_kelas` (`id`, `nama_kelas`) VALUES
(1, 'IT'),
(3, 'BIDAN'),
(4, 'PERAWAT'),
(5, 'KEUANGAN'),
(6, 'APOTEKER'),
(7, 'LABORATORIUM'),
(8, 'ASSISTEN APOTEKER'),
(9, 'ASSISTEN GIGI'),
(10, 'KEUANGAN'),
(11, 'ADMINISTRASI DAN PEDAFTARAN'),
(12, 'RADIOLOGI');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `robot80_tb_kelas`
--
ALTER TABLE `robot80_tb_kelas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `robot80_tb_kelas`
--
ALTER TABLE `robot80_tb_kelas`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
