-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 26 Bulan Mei 2026 pada 07.08
-- Versi server: 10.4.16-MariaDB
-- Versi PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikdraisyah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `robot80_data_upgrade`
--

CREATE TABLE `robot80_data_upgrade` (
  `id` int(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `link` varchar(500) NOT NULL,
  `update` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `robot80_data_upgrade`
--

INSERT INTO `robot80_data_upgrade` (`id`, `nama`, `link`, `update`) VALUES
(1, 'myROBOT-V80', 'https://github.com/klinikasura/APLIKASI-V80/releases/', '2026-05-20 08:40:33'),
(2, 'SIMRS KHANZA', 'https://drive.google.com/drive/folders/1CskGfpj45DyF7vxVhPR4U9pE_Fz9L30R', '2026-05-20 08:40:33'),
(3, 'MLITE', 'https://github.com/basoro/mlite', '2026-05-20 08:40:33'),
(4, 'MEDIAN.CO', 'https://median.co/app/6m6ejtqmxzwz18px7dxh4exzrg/build', '2026-05-20 08:40:33');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `robot80_data_upgrade`
--
ALTER TABLE `robot80_data_upgrade`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
