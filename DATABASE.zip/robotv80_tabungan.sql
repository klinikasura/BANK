-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 26 Bulan Mei 2026 pada 07.07
-- Versi server: 10.4.16-MariaDB
-- Versi PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikdraisyah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `robotv80_tabungan`
--

CREATE TABLE `robotv80_tabungan` (
  `id_tabungan` int(11) NOT NULL,
  `id_karyawan` int(11) DEFAULT NULL,
  `saldo` decimal(10,2) DEFAULT NULL,
  `tanggal` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `robotv80_tabungan`
--

INSERT INTO `robotv80_tabungan` (`id_tabungan`, `id_karyawan`, `saldo`, `tanggal`) VALUES
(1, 1, '81099500.00', '2026-02-13'),
(2, 2, '0.00', '2026-02-13');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `robotv80_tabungan`
--
ALTER TABLE `robotv80_tabungan`
  ADD PRIMARY KEY (`id_tabungan`),
  ADD KEY `id_karyawan` (`id_karyawan`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `robotv80_tabungan`
--
ALTER TABLE `robotv80_tabungan`
  MODIFY `id_tabungan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `robotv80_tabungan`
--
ALTER TABLE `robotv80_tabungan`
  ADD CONSTRAINT `robotv80_tabungan_ibfk_1` FOREIGN KEY (`id_karyawan`) REFERENCES `robotv80_karyawan` (`id_karyawan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
