-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 26 Bulan Mei 2026 pada 07.08
-- Versi server: 10.4.16-MariaDB
-- Versi PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikdraisyah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `robotv80_transaksi`
--

CREATE TABLE `robotv80_transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `id_tabungan` int(11) DEFAULT NULL,
  `jenis_transaksi` enum('Setor','Tarik','Transfer') DEFAULT NULL,
  `jumlah` decimal(10,2) DEFAULT NULL,
  `tanggal` datetime DEFAULT current_timestamp(),
  `transfer_ke` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `robotv80_transaksi`
--

INSERT INTO `robotv80_transaksi` (`id_transaksi`, `id_tabungan`, `jenis_transaksi`, `jumlah`, `tanggal`, `transfer_ke`) VALUES
(1, 2, 'Transfer', '50000.00', '2026-02-13 15:30:35', ''),
(2, 1, 'Transfer', '50000.00', '2026-02-13 15:30:35', ''),
(3, 2, 'Transfer', '100000.00', '2026-02-13 16:26:46', ''),
(4, 1, 'Transfer', '100000.00', '2026-02-13 16:26:46', ''),
(5, 1, 'Setor', '10000000.00', '2026-02-14 14:25:12', ''),
(6, 2, 'Transfer', '10000.00', '2026-02-14 14:26:54', ''),
(7, 1, 'Transfer', '10000.00', '2026-02-14 14:26:54', ''),
(8, 1, 'Setor', '100000.00', '2026-05-24 13:01:44', ''),
(9, 1, 'Tarik', '100000.00', '2026-05-24 13:02:36', ''),
(10, 2, 'Transfer', '50.00', '2026-05-24 13:03:18', ''),
(11, 1, 'Transfer', '50.00', '2026-05-24 13:03:18', ''),
(12, 2, 'Transfer', '50.00', '2026-05-24 13:18:46', 'Asep Pudin, Amd'),
(13, 1, 'Transfer', '50.00', '2026-05-24 13:21:49', 'Wayan Ediarte, S.Kep. Ners'),
(14, 2, 'Transfer', '50.00', '2026-05-24 13:24:57', 'Asep Pudin, Amd'),
(15, 2, 'Transfer', '50.00', '2026-05-24 15:34:14', 'Asep Pudin, Amd'),
(16, 2, 'Transfer', '700.00', '2026-05-24 15:46:56', 'Asep Pudin, Amd'),
(17, 2, 'Transfer', '400.00', '2026-05-24 16:14:16', 'Asep Pudin, Amd'),
(18, 2, 'Tarik', '20.00', '2026-05-25 09:13:54', '	\r\nTarik'),
(19, 1, 'Tarik', '100.00', '2026-05-25 09:23:53', ''),
(20, 2, 'Setor', '500.00', '2026-05-25 09:24:27', ''),
(21, 1, 'Tarik', '700.00', '2026-05-25 09:34:01', ''),
(22, 2, 'Transfer', '100.00', '2026-05-25 09:34:53', 'Asep Pudin, Amd'),
(23, 2, 'Transfer', '400.00', '2026-05-25 09:38:11', 'Asep Pudin, Amd'),
(24, 2, 'Transfer', '750.00', '2026-05-25 11:22:34', 'Asep Pudin, Amd'),
(25, 1, 'Setor', '50000.00', '2026-05-25 11:27:10', ''),
(26, 1, 'Setor', '3500.00', '2026-05-25 12:47:45', ''),
(27, 1, 'Setor', '2000.00', '2026-05-25 12:48:14', ''),
(28, 1, 'Setor', '1000.00', '2026-05-25 12:48:29', ''),
(29, 2, 'Transfer', '400.00', '2026-05-25 12:50:16', '1'),
(30, 1, 'Transfer', '100.00', '2026-05-26 09:28:18', '2'),
(31, 2, 'Transfer', '4100.00', '2026-05-26 09:34:31', '1'),
(32, 1, 'Transfer', '100.00', '2026-05-26 09:38:45', 'Wayan Ediarte, S.Kep. Ners'),
(33, 2, 'Transfer', '100.00', '2026-05-26 09:42:35', 'Asep Pudin, Amd'),
(34, 1, 'Tarik', '4000.00', '2026-05-26 09:42:58', ''),
(35, 1, 'Transfer', '100.00', '2026-05-26 09:43:20', 'Wayan Ediarte, S.Kep. Ners'),
(36, 1, 'Transfer', '800.00', '2026-05-26 04:55:35', 'Wayan Ediarte, S.Kep. Ners'),
(37, 2, 'Transfer', '800.00', '2026-05-26 04:55:35', 'Asep Pudin, Amd'),
(38, 1, 'Transfer', '800.00', '2026-05-26 04:56:19', 'Wayan Ediarte, S.Kep. Ners'),
(39, 2, 'Transfer', '800.00', '2026-05-26 04:56:19', 'Asep Pudin, Amd'),
(40, 1, 'Transfer', '200.00', '2026-05-26 04:57:20', 'Wayan Ediarte, S.Kep. Ners'),
(41, 2, 'Transfer', '200.00', '2026-05-26 04:57:20', 'Asep Pudin, Amd'),
(42, 2, 'Transfer', '3000.00', '2026-05-26 04:59:34', 'Asep Pudin, Amd'),
(43, 1, 'Transfer', '3000.00', '2026-05-26 04:59:34', 'Wayan Ediarte, S.Kep. Ners'),
(44, 1, 'Transfer', '100.00', '2026-05-26 05:04:01', 'Wayan Ediarte, S.Kep. Ners'),
(45, 2, 'Transfer', '100.00', '2026-05-26 05:04:27', 'Asep Pudin, Amd'),
(46, 1, 'Transfer', '100.00', '2026-05-26 05:13:33', 'Wayan Ediarte, S.Kep. Ners'),
(47, 2, 'Transfer', '100.00', '2026-05-26 10:20:56', '1'),
(48, 1, 'Setor', '1000000.00', '2026-05-26 10:21:19', ''),
(49, 1, 'Setor', '1000000.00', '2026-05-26 10:21:56', ''),
(50, 1, 'Setor', '50000000.00', '2026-05-26 10:22:47', ''),
(51, 1, 'Setor', '50000000.00', '2026-05-26 10:23:03', ''),
(52, 1, 'Setor', '20000000.00', '2026-05-26 10:23:21', ''),
(53, 1, 'Tarik', '1000000.00', '2026-05-26 10:23:50', ''),
(54, 1, 'Transfer', '1000000.00', '2026-05-26 10:24:33', '2'),
(55, 2, 'Transfer', '1000000.00', '2026-05-26 10:25:25', 'Asep Pudin, Amd'),
(56, 1, 'Transfer', '100.00', '2026-05-26 05:40:31', 'Wayan Ediarte, S.Kep. Ners'),
(57, 1, 'Transfer', '500000.00', '2026-05-26 05:40:49', 'Wayan Ediarte, S.Kep. Ners'),
(58, 2, 'Transfer', '500100.00', '2026-05-26 06:03:54', 'Asep Pudin, Amd');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `robotv80_transaksi`
--
ALTER TABLE `robotv80_transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `id_tabungan` (`id_tabungan`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `robotv80_transaksi`
--
ALTER TABLE `robotv80_transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `robotv80_transaksi`
--
ALTER TABLE `robotv80_transaksi`
  ADD CONSTRAINT `robotv80_transaksi_ibfk_1` FOREIGN KEY (`id_tabungan`) REFERENCES `robotv80_tabungan` (`id_tabungan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
