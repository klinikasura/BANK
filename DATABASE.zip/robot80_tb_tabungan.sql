-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 26 Bulan Mei 2026 pada 07.07
-- Versi server: 10.4.16-MariaDB
-- Versi PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikdraisyah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `robot80_tb_tabungan`
--

CREATE TABLE `robot80_tb_tabungan` (
  `id_tabungan` int(100) NOT NULL,
  `id_siswa` text NOT NULL,
  `nama` text NOT NULL,
  `kelas` text NOT NULL,
  `tanggal` date DEFAULT NULL,
  `setoran` int(100) NOT NULL,
  `penarikan` int(100) NOT NULL,
  `saldo` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `robot80_tb_tabungan`
--

INSERT INTO `robot80_tb_tabungan` (`id_tabungan`, `id_siswa`, `nama`, `kelas`, `tanggal`, `setoran`, `penarikan`, `saldo`) VALUES
(5, '014', 'Asep Pudin, Amd', 'IT', '2025-07-20', 1000000000, 0, 1012000000);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `robot80_tb_tabungan`
--
ALTER TABLE `robot80_tb_tabungan`
  ADD PRIMARY KEY (`id_tabungan`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `robot80_tb_tabungan`
--
ALTER TABLE `robot80_tb_tabungan`
  MODIFY `id_tabungan` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
