-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 26 Bulan Mei 2026 pada 07.07
-- Versi server: 10.4.16-MariaDB
-- Versi PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikdraisyah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `robot80_tb_siswa`
--

CREATE TABLE `robot80_tb_siswa` (
  `id` int(100) NOT NULL,
  `nama` text NOT NULL,
  `kelas` text NOT NULL,
  `alamat` text NOT NULL,
  `notlp` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `robot80_tb_siswa`
--

INSERT INTO `robot80_tb_siswa` (`id`, `nama`, `kelas`, `alamat`, `notlp`) VALUES
(9, 'Asep Pudin, Amd', 'IT', '-', '-'),
(26, 'Wayan Ediarte, S.Kep. Ners', 'PERAWAT', 'http://10.10.20.250/dashboard/APPS-ROBOT/DATABASE-KARYAWAN/admin/gambar_anggota/WhatsApp%20Image%202024-11-21%20at%2008.39.18.jpeg', '081337131773');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `robot80_tb_siswa`
--
ALTER TABLE `robot80_tb_siswa`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `robot80_tb_siswa`
--
ALTER TABLE `robot80_tb_siswa`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
