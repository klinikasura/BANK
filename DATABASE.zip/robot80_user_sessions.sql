-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 26 Bulan Mei 2026 pada 07.07
-- Versi server: 10.4.16-MariaDB
-- Versi PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikdraisyah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `robot80_user_sessions`
--

CREATE TABLE `robot80_user_sessions` (
  `id` int(100) NOT NULL,
  `user_id` int(100) DEFAULT NULL,
  `login_time` datetime DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `robot80_user_sessions`
--

INSERT INTO `robot80_user_sessions` (`id`, `user_id`, `login_time`, `last_activity`, `is_active`) VALUES
(1019, 36, '2026-05-25 08:56:55', '2026-05-26 04:24:16', 1),
(1020, 36, '2026-05-25 08:57:59', '2026-05-26 04:24:16', 1),
(1021, 36, '2026-05-25 14:57:33', '2026-05-26 04:24:16', 1),
(1022, 36, '2026-05-26 09:08:45', '2026-05-26 04:24:16', 1),
(1023, 36, '2026-05-26 09:24:16', '2026-05-26 04:24:16', 1);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `robot80_user_sessions`
--
ALTER TABLE `robot80_user_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `robot80_user_sessions`
--
ALTER TABLE `robot80_user_sessions`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1024;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
