-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 26 Bulan Mei 2026 pada 07.08
-- Versi server: 10.4.16-MariaDB
-- Versi PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikdraisyah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `robot80_data_buku`
--

CREATE TABLE `robot80_data_buku` (
  `id` int(255) NOT NULL,
  `judul` varchar(500) NOT NULL,
  `isbn` varchar(500) NOT NULL,
  `asal` varchar(500) NOT NULL,
  `tgl_input` varchar(500) NOT NULL,
  `gambar` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `robot80_data_buku`
--

INSERT INTO `robot80_data_buku` (`id`, `judul`, `isbn`, `asal`, `tgl_input`, `gambar`) VALUES
(1, 'STRA DESI APOTEKER', 'STRA DESI APOTEKER', 'STR', '2024/12/14', 'gambar_buku/STRA DESI KRISMAWATI SEUMUR HIDUP_page-0001.jpg'),
(2, 'STR EKA ASSISTEN APOTEKER', 'STR EKA ASSISTEN APOTEKER', 'STR', '2024/12/14', 'gambar_buku/STR EKA SEUMUR HIDUP_page-0001.jpg'),
(3, 'STR ELI BIDAN', 'STR ELI BIDAN', 'STR', '2024/12/14', 'gambar_buku/STR ELI SEUMUR HIDUP_page-0001.jpg'),
(5, 'STR INDAH ANALIS KESEHATAN', 'STR INDAH ANALIS KESEHATAN', 'STR', '2024/12/14', 'gambar_buku/STR INDAH ANALIS KESEHATAN SEUMUR HIDUP_page-0001.jpg'),
(6, 'STR INDRIANA BIDAN', 'STR INDRIANA BIDAN', 'STR', '2024/12/14', 'gambar_buku/STR DIANA SEUMUR HIDUP_page-0001.jpg'),
(7, 'STR MARLITA YANTI PERAWAT', 'STR MARLITA YANTI PERAWAT', 'STR', '2024/12/14', 'gambar_buku/STR ITA BARU_page-0001.jpg'),
(8, 'STR KADEK ANALIS KESEHATAN', 'STR KADEK ANALIS KESEHATAN', 'STR', '2024/12/14', 'gambar_buku/STR KADEK SEUMUR HIDUP_page-0001.jpg'),
(9, 'STR KOMANG PERAWAT', 'STR KOMANG PERAWAT', 'STR', '2024/12/14', 'gambar_buku/STR KOMANG SEUMUR HIDUP_page-0001.jpg'),
(10, 'STR RANDI PERAWAT', 'STR RANDI PERAWAT', 'STR', '2024/12/14', 'gambar_buku/STR RANDI SEUMUR HIDUP_page-0001.jpg'),
(11, 'STR RIKA BIDAN', 'STR RIKA BIDAN', 'STR', '2024/12/14', 'gambar_buku/STR RIKA SEUMUR HIDUP_page-0001.jpg'),
(12, 'STR WAYAN PERAWAT', 'STR WAYAN PERAWAT', 'STR', '2024/12/14', 'gambar_buku/STR WAYAN SEUMUR HIDUP_page-0001.jpg'),
(13, 'STR EGI PERAWAT', 'STR EGI PERAWAT', 'STR', '2025/10/29', '../anggota/gambar_buku/Egi Diah Safitri_Berkas Lamaran Kerja-3.jpg'),
(14, 'STR SITI PERAWAT', 'STR SITI PERAWAT', 'STR', '2025/10/29', '../anggota/gambar_buku/SITI-5.jpg'),
(15, 'STR ANI BIDAN', 'STR ANI BIDAN', 'STR', '2025/11/01', 'gambar_buku/ani marsela-3_page-0001.jpg'),
(16, 'STR PIKA', 'STR PIKA', 'STR', '2025/11/24', '../anggota/gambar_buku/5_page-0001.jpg');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `robot80_data_buku`
--
ALTER TABLE `robot80_data_buku`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `robot80_data_buku`
--
ALTER TABLE `robot80_data_buku`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1112;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
