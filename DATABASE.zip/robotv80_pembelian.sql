-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 26 Bulan Mei 2026 pada 07.07
-- Versi server: 10.4.16-MariaDB
-- Versi PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikdraisyah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `robotv80_pembelian`
--

CREATE TABLE `robotv80_pembelian` (
  `id_beli` int(11) NOT NULL,
  `id_karyawan` int(11) DEFAULT NULL,
  `id_barang` int(11) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `tanggal` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `robotv80_pembelian`
--

INSERT INTO `robotv80_pembelian` (`id_beli`, `id_karyawan`, `id_barang`, `jumlah`, `total`, `tanggal`) VALUES
(1, 1, 3, 1, '500.00', '2026-05-25 10:54:00'),
(2, 1, 3, 1, '500.00', '2026-05-25 10:57:29'),
(3, 1, 3, 100, '50000.00', '2026-05-25 11:26:00'),
(4, 1, 3, 1, '500.00', '2026-05-25 11:44:03'),
(5, 1, 3, 1, '500.00', '2026-05-25 11:46:08'),
(6, 1, 3, 1, '500.00', '2026-05-25 11:46:23'),
(7, 1, 3, 1, '500.00', '2026-05-25 11:46:42'),
(8, 1, 3, 1, '500.00', '2026-05-25 11:51:16'),
(9, 1, 3, 1, '500.00', '2026-05-26 10:15:19');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `robotv80_pembelian`
--
ALTER TABLE `robotv80_pembelian`
  ADD PRIMARY KEY (`id_beli`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `robotv80_pembelian`
--
ALTER TABLE `robotv80_pembelian`
  MODIFY `id_beli` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
