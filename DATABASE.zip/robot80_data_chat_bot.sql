-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 26 Bulan Mei 2026 pada 07.08
-- Versi server: 10.4.16-MariaDB
-- Versi PHP: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikdraisyah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `robot80_data_chat_bot`
--

CREATE TABLE `robot80_data_chat_bot` (
  `id` int(11) NOT NULL,
  `queries` varchar(300) NOT NULL,
  `replies` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `robot80_data_chat_bot`
--

INSERT INTO `robot80_data_chat_bot` (`id`, `queries`, `replies`) VALUES
(1, 'Tes', 'Tes'),
(2, 'Hai', 'hai juga'),
(3, 'simrs', 'oh SIMRS, bisa akses ke aplikasi robot ya atau ke komputer langsung'),
(4, 'Waalaikumsalam', 'Terima kasih sudah menjawab salam'),
(5, 'robot', 'saya sedangan dalam pengembangan luar biasa untuk agar lebih keren lagi kedepan nya'),
(6, 'hmmm', 'Kenapa ? ada yang bisa aku bantu'),
(7, 'aplikasi', 'ya saya AI ROBOT SYSTEM V80'),
(8, '.', 'apakah kamu perlu bantuan'),
(9, 'daftar pasien', 'boleh, bisa pilih menu daftar pasien ya'),
(10, 'soap', 'boleh, klik menu soap ya'),
(11, 'Asep Pudin New', 'IT DEVELOPMENT KODE 008 AI ROBOT SYSTEM V80'),
(12, 'keren', 'kamu juga keren, terima kasih');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `robot80_data_chat_bot`
--
ALTER TABLE `robot80_data_chat_bot`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
